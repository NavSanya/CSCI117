
-- From Tutorial
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecordWildCards   #-}
{-# LANGUAGE TupleSections #-}

module OzParser (main,main') where

import Oz
import Control.Applicative hiding (many, some)
import Control.Monad
import Data.Text (Text)
import Data.Void
import Data.Char (isSpace)
import Text.Megaparsec hiding (State)
import Text.Megaparsec.Char
import qualified Data.Text as T
import qualified Text.Megaparsec.Char.Lexer as L
import Debug.Trace 
import System.IO

type Parser = Parsec Void String

-- From Tutorial (END)

-- Run tests
-- -> parseTest <parser> <Text>

-- Helper functions/parser

-- MarkKaprov tutorial (parsing a simple imperative language)
-- space consumer
sc :: Parser ()
sc = L.space space1 lineCmnt blockCmnt
  where
    lineCmnt = L.skipLineComment "//"
    blockCmnt = L.skipBlockComment "/*" "*/"


-- wrap lexeme so it parses white space after it
lexeme :: Parser a -> Parser a
lexeme = L.lexeme sc

-- parse string and whitespace after
symbol :: String -> Parser String
symbol = L.symbol sc

-- reserved word parsers followed by at least one space
rword :: String -> Parser String
rword w = (lexeme . try) (string w <* notFollowedBy alphaNumChar)

-- reserved words
rws :: [String]
rws = ["skip","local","in","end","case","of","if","else","then","Proc","Browse"]

-- parsing an identifier 
-- starts with upper case letter, cannot be a reserved word
-- no underscore, no quote names
pIdentifier :: Parser String
pIdentifier = try (p >>= check)
  where
    p = (:) <$> upperChar <*> many alphaNumChar
    check x = if x `elem` rws
          then fail $ "keyword " ++ show x ++ " cannot be an identifier"
          else return x

-- parsing an atom
-- starts with lower case letter, cannot be reserved word
-- OR
-- starts with single quote, ends with single quote
pAtom :: Parser String 
pAtom = try ( (p >>= check) <|> pSingleQuotes)
  where
    p = (:) <$> lowerChar <*> many alphaNumChar
    check x = if x `elem` rws
          then fail $ "keyword " ++ show x ++ " cannot be an identifier"
          else return x
    pSingleQuotes = do 
      x <- singleQuotes
      return ("\'"++x++"\'")
    singleQuotes = between (char '\'') (char '\'') (many (satisfy (not . (== '\''))))

-- consume 0 or more whitespace, comments, newlines (all inclusive whitespace consumer)
-- not sure if this works correclt because skipLineComment and skipBlockComment
sc' :: Parser ()
sc' = do
  s <- optional (some $ satisfy (isSpace))
  void (optional (L.skipLineComment "//"))
  void (optional (L.skipBlockComment ("/*") ("*/")))
  n <- optional (some $ satisfy (== '\n'))
  (if (mh s n) then return () else (() <$ sc'))
  where
    mh Nothing Nothing = True
    mh _ _ = False

-- Values
pValue :: Parser PVal
pValue = pNum 
  <|> pProcedure 
  <|> pRecord

-- https://mmhaskell.com/parsing-4 for number example
pNum :: Parser PVal
pNum = pNegative <|> pFloat <|> pInteger
  where
    pFloat :: Parser PVal
    pFloat = try $ do
      whole <- many digitChar
      void (char '.')
      fractional <- many digitChar
      let num = (PFloat . read) (whole ++ ('.':fractional))
      return num
    pInteger :: Parser PVal
    pInteger = try $ do
      int <- some digitChar
      let num = (PInt . read) int
      return num
    pNegative :: Parser PVal
    pNegative = try $ do
      void (char '-')
      num <- pFloat <|> pInteger
      return (case num of
        (PFloat x) -> PFloat (-x)
        (PInt x) -> PInt (-x))

pRecord :: Parser PVal
pRecord = try $ do
  label <- pLabel
  openParen <- (optional . try) (char '(')
  features <- (case openParen of
        (Just x) -> do 
          ps <- many pPairs
          sc'
          char ')'
          sc'
          return ps
        Nothing -> do
          sc'
          return [])
  return $ PRec (label, (features))
  where
    pLabel :: Parser String
    pLabel = pLiteral
    pPairs :: Parser (String,String)
    pPairs = do
      feat <- pFeature
      void (char ':')
      identifier <- pIdentifier <* sc'
      return (feat,identifier) 

pProcedure :: Parser PVal
pProcedure = try $ do
  void (rword "proc")
  void (sc')
  void (char '{' <* sc')
  void (char '$')
  void (sc')
  parameters <- many (pIdentifier <* sc') -- space after ...
  void (char '}')
  void (sc')
  body <- pStatement -- statement parser
  void (rword "end")
  return (PProc parameters body)

pLiteral :: Parser String
pLiteral = pAtom

pFeature :: Parser String
pFeature = 
  try pAtom <|>
  do 
    num <- many digitChar
    return num

pBool :: Parser PVal
pBool = 
  (PRec ("true",[])) <$ string "True" <|>
  (PRec ("false",[])) <$ string "False"

{---- Oz Syntax ----------------------

In this simplified Oz syntax, record labels and features are atoms (strings),
where we use "1", "2", etc., for integer features and "true" and "false" for
Boolean features, sequences of statements are represented by lists, and the
skip statement doubles as a state-output statement.  

type Var    = String                       -- Program variables
type Atom   = String                       -- Atoms
type RecLit = (Atom, [(Atom,Var)])         -- Record literals (label, feat/vars)

-- Program values
data PVal = PInt Int                       -- Integer literals
          | PFloat Float                   -- Floating-point literals
          | PRec RecLit                    -- Record literals
          | PProc [Var] [Stmt]             -- Procedures (args, body)
         
-- Statements
data Stmt = Skip SkipType                  -- Empty statement (optional output)
          | Thread [Stmt]                  -- Thread introduction
          | Local [Var] [Stmt]             -- Variable introduction (multiple)
          | EqVar Var Var                  -- Variable-variable binding
          | EqVal Var PVal                 -- Variable-value binding
          | If Var [Stmt] [Stmt]           -- Conditional statement
          | Case Var RecLit [Stmt] [Stmt]  -- Pattern matching
          | NewName Var                    -- Name introduction
          | Apply Var [Var]                -- Procedure application
          | IsDet Var Var                  -- State: determined?
          | NewCell Var Var                -- State: new cell
          | Exchange Var Var Var           -- State: exchange cells
          | ByNeed Var Var                 -- Laziness: by-need trigger
          | TryCatch [Stmt] Var [Stmt]     -- Exception handling: try/catch
          | Raise Var                      -- Exception handling: raise

data SkipType = Basic                      -- Ordinary skip
              | Store                      -- Skip and display store
              | Full                       -- Skip and display environ + store
              | Check                      -- Skip and check state invariants
-}

-- get rid of space before program starts, end at end of file
pStatements :: Parser [Stmt]
pStatements = between sc' eof pStatement

-- cycle through all statements as options (s1)
-- if there is more statements, create a list
pStatement :: Parser [Stmt]
pStatement = do 
  s1 <- (pSkip   <|>
    pLocal   <|>
    pBind    <|>
    pBindVal <|>
    pIf      <|>
    pCase    <|>
    pProcApp)
  s2 <- (optional . try) $ pStatement
  return $
    case s2 of 
      Nothing -> [s1]
      (Just stm) -> (s1:stm)

pSkip :: Parser Stmt
pSkip = pSkipB
  <|> pSkipS
  <|> pSkipF
  <|> pSkipC
  <|> pSkipBr
  <|> pSkipSt
  where
    pSkipB = try $ (Skip Basic) <$ string "skip" <* sc' <* string "Basic" <* sc'
    pSkipS = try $ (Skip Store) <$ string "skip" <* sc' <* string "Store" <* sc'
    pSkipF = try $ (Skip Full) <$ string "skip" <* sc' <* string "Full" <* sc'
    pSkipC = try $ (Skip Check) <$ string "skip" <* sc' <* string "Check" <* sc'
    pSkipBr = try $ do
      string "skip" <* sc' <* string "Browse" <* sc'
      id <- pIdentifier <* sc'
      return $ Skip (Browse id)
    pSkipSt = try $ (Skip Stack) <$ string "skip" <* sc' <* string "Stack" <* sc'

pLocal :: Parser Stmt
pLocal = do
  void (rword "local")
  identifiers <- many $ pIdentifier <* sc'
  void (rword "in" <* sc')
  body <- pStatement
  void (rword "end" <* sc')
  return (Local identifiers body)

pBind :: Parser Stmt
pBind = try $ do
  identifier1 <- pIdentifier <* sc'
  void (char '=' <* sc')
  identifier2 <- pIdentifier <* sc'
  return (EqVar identifier1 identifier2)

pBindVal :: Parser Stmt
pBindVal = try $ do
  identifier1 <- pIdentifier <* sc'
  void (char '=' <* sc')
  val <- pValue <* sc'
  return (EqVal identifier1 val)

pIf :: Parser Stmt
pIf = do
  void (rword "if" <* sc')
  identifier <- pIdentifier <* sc'
  void (rword "then" <* sc')
  s1 <- pStatement
  void (rword "else" <* sc')
  s2 <- pStatement
  void (rword "end" <* sc')
  return (If identifier s1 s2)

pCase :: Parser Stmt
pCase = do
  void (rword "case" <* sc')
  identifier <- pIdentifier <* sc'
  void (rword "of" <* sc')
  (PRec pattern) <- pRecord <* sc'
  void (rword "then" <* sc')
  s1 <- pStatement
  void (rword "else" <* sc')
  s2 <- pStatement
  void (rword "end" <* sc')
  return (Case identifier pattern s1 s2)

pProcApp :: Parser Stmt
pProcApp = try $ do
  void (char '{' <* sc')
  procIdentifier <- pIdentifier <* sc'
  arguments <- many (pIdentifier <* sc') -- include white space take
  void (char '}' <* sc')
  return (Apply procIdentifier arguments)

-- comand line run 
-- > cat test.txt | ./ozParser
-- read IO, Ouput -> (Left is error, Right is Stm), PutStr to display
main :: IO ()
main = do 
  input <- getContents
  case parse pStatements "" input of
    (Left bundle) -> putStr (errorBundlePretty bundle)
    (Right xs) -> putStr (seq (oz_p xs) ((show xs)++"\n")) -- instead of show, use execute_program to run


-- ghci run
-- ghci> main' "infile.txt" "outfile.txt"
--   Haskell statement structure written to output file
--   calls to Skip displays are written to terminal
main' :: String -> String -> IO ()
main' inF outF = do 
  input <- readFile inF
  case parse pStatements "" input of
    (Left bundle) -> putStr (errorBundlePretty bundle)
    (Right xs) -> do
      seq (oz_p xs) $ writeFile outF (show xs)


oz_p s = case (oz s) of
  SDone -> 0
  (SError st) -> trace (st) 0








