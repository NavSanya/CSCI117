
-- From Tutorial
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecordWildCards   #-}


module OzKernelSyntaxParser () where


import Control.Applicative hiding (many, some)
import Control.Monad
import Control.Monad.State.Strict -- important for strict state ...
import Data.Text (Text)
import Data.Void
import Data.Char (isSpace)
import Text.Megaparsec hiding (State)
import Text.Megaparsec.Char
import qualified Data.Text as T
import qualified Text.Megaparsec.Char.Lexer as L
import System.IO
import Debug.Trace

import OzParser

type ParserT a = ParsecT Void String (State Int) a -- using state to store tab space

-- From Tutorial (END)

-- Run tests
-- -> parseTest <parser> <Text>

-- ghc ozKernelSyntaxParser.hs
-- cat test.txt | ./ozKernelSyntaxParser 

-- Everything replicated from ozParser ends with K, to signify Kernel Syntax



-- *********************************************************************************************************************
-- Helper Functions

-- Input String, Number of spaces to add at beggining of each line
ts :: String -> Int -> String
ts [] i = []
ts s i = (spcs i) ++ (foldl (\x y -> x ++ (if y=='\n' then "\n"++(spcs i) else [y])) [] (init s)) ++ "\n"
spcs n = replicate n ' '

-- spaces based on inner monad State (Int)
tsm :: String -> ParserT String
tsm s = do 
  tab <- get
  return (ts s tab)

-- endWithTav x n, gives a list of x ends with n spaces before the first end
endWithTab :: Int -> Int -> String
endWithTab x n = ts (concat (replicate x ("end "))) n ++ "\n"

-- consume 0 or more whitespace, comments, newlines (all inclusive whitespace consumer)
scK :: ParserT String
scK = do
  s <- optional (some $ satisfy (isSpace))
  l <- optional (pLineCommentK)
  b <- optional (pBlockCommentK)
  n <- optional (some $ satisfy (== '\n'))
  let sps = mh s (mh l (mh b n))
  case sps of
    (Just x) -> (x++) <$> scK
    Nothing ->  return []
  where
    mh Nothing Nothing = Nothing
    mh (Just x) Nothing = Just x
    mh Nothing (Just x) = Just x
    mh (Just x) (Just y) = Just (x++y)

-- 0 or more spaces
spaceK :: ParserT String
spaceK = many (satisfy (== ' '))

-- char wrapped with space consumer
charSC :: Char -> ParserT Char
charSC c = char c <* scK

-- line comment
pLineCommentK :: ParserT String
pLineCommentK = do
  void (string "//")
  cmt <- many (satisfy (not . (== '\n')))
  return ("//"++cmt)

-- block comment
pBlockCommentK :: ParserT String
pBlockCommentK = do
  void (string "/*")
  cmt <- many (satisfy (not . (== '*')) :: ParserT Char)
  void (char '*')
  slash <- (optional . try) $ char '/'
  case slash of 
    (Just x) -> return ("/*" ++ cmt ++ "*/")
    Nothing -> pH cmt
  where
    pH :: String -> ParserT String
    pH cm = do 
      cmt1 <- many (satisfy (not . (=='*')) :: ParserT Char)
      void (char '*')
      slash1 <- (optional . try) $ char '/'
      case slash1 of 
        (Just x) -> return ("/*" ++ cm ++ cmt1 ++ "*/")
        Nothing -> pH (cm ++ cmt1)

-- calculate spaces after a newline I guess? Never used ... 
spacesAfterNL :: String -> Int
spacesAfterNL [] = 0
spacesAfterNL ('\n':s) = length s
spacesAfterNL (s:ss) = spacesAfterNL ss


-- *********************************************************************************************************************
-- In Statement Declarations
-- [ { ⟨declarationPart⟩ }+ in ] ⟨statement⟩
pInStatement :: ParserT String
pInStatement = try $ do
  decPart <- optional pDeclarationPart
  case decPart of
    (Just (dec,n)) -> do
      tab1 <- get
      let tabbedDec = ts dec tab1
      modify (+2)
      body <- pStatementK
      modify (subtract 2)
      let ends = endWithTab n tab1
      return (tabbedDec++body++ends)
    Nothing ->do 
      modify (+2)
      s <- pStatementK
      modify (subtract 2)
      return s

-- declaration of variables before a statement
-- variables by themselves or pattern = exp 
-- only manages the expresions after the locals are unfolded (locals and ends handled by calling statement)
-- DeclarationPart = e | (id | pattern = exp ) DeclarationPart
-- Int represents the number of "end" to be added after the body of InStatement determined by number of locals created
pDeclarationPart :: ParserT (String,Int)
pDeclarationPart = try $ do
  pat <- pPattern
  eq <- optional (charSC '=')
  (lcl,ns) <- (case eq of 
    Just c -> do
      exp1 <- pExp
      case pat of
        (Varp x) -> do
          let decl = ts (exp2Kernel x exp1) 2
          return (("local "++x++" in\n"++decl),1)
        _ -> do
          let (patK,ns') = pattern2kernel pat "UniqueNameDP"
          let decl = ts (exp2Kernel "UniqueNameDP" exp1) 2
          return (patK++decl++"end\n",ns')
    Nothing -> do
      let {id1 = (case pat of
        (Varp x) -> x
        _ -> error $ "pattern incorrectly used -> "++(show pat))}
      return (("local "++id1++" in\n"),1))
  opt <- optional (pDeclarationPart)
  case opt of 
    (Just (rest,n')) -> return (lcl++rest,(n'+ns))
    Nothing -> do 
      void (rwordSC "in")
      return (lcl,ns)

-- *********************************************************************************************************************
-- Patterns

data Pat = Varp String | Nump String | Atomp String | Rcrdp String [(String,Pat)] | Parenp Pat String Pat
instance Show Pat where
  show (Nump s) = show s
  show (Varp s) = show s
  show (Atomp s) = show s
  show (Rcrdp s fs) = show s ++ " " ++ show fs
  show (Parenp e1 b e2) = show e1 ++ " " ++ show b ++ " " ++ show e2

rcbos :: [Char]
rcbos = ['#','|']

rcBinOp :: ParserT String
rcBinOp = (:[]) <$> satisfy (\x-> elem x rcbos)

-- no lists for now in the pattern
-- scK after each pattern type
pPattern:: ParserT Pat
pPattern = try $ do
  ((Varp <$> pIdentifierK)
    <|> pRcd 
    <|> (Atomp <$> pAtomK) 
    <|> (Nump <$> pNumK) 
    <|> pParen) <* scK -- patterns with consBinOp
  where
    pRcd :: ParserT Pat
    pRcd = try $ do
      label <- pLiteralK
      openParen <- (optional . try) (char '(')
      features <- (case openParen of
        (Just x) -> do 
          ps <- many pPairsK
          charSC ')'
          return ps
        Nothing -> do
          scK 
          return [])
      return $ Rcrdp label features
      where
        pPairsK :: ParserT (String,Pat)
        pPairsK = do
          feat <- pFeatureK
          void (char ':')
          pat <- pPattern
          return (feat,pat)
    pParen :: ParserT Pat
    pParen = do
      void (charSC '(')
      pt1 <- pPattern
      op <- rcBinOp <* scK
      pt2 <- pPattern
      void (char ')')
      return $ Parenp pt1 op pt2

-- construct a record from the pattern and bind it to the input identifier
pattern2record :: Pat -> String -> String
pattern2record pat id = 
  let
    (idN,bN,nN) = p2rh pat id 0
    ends = endWithTab (nN-1) 0
    bNend = bN++ends in
    (bNend)
  where 
    p2rh :: Pat -> String -> Int -> (String,String,Int)
    p2rh (Varp var) id' n = (var,[],0)
    p2rh (Nump s) id' n = (id',"local "++id'++" in\n"++id'++" = "++s++"\n",1)
    p2rh (Atomp s) id' n = (id',"local "++id'++" in\n"++id'++" = "++s++"\n",1)
    p2rh (Rcrdp lbl []) id' n = (id',"local "++id'++" in\n"++id'++" = "++lbl++"\n",1)
    p2rh (Rcrdp lbl feats) id' n = let
      fnms = map fst feats
      fPats = map snd feats 
      foldPat :: Pat -> ([((String,String,Int))],Int) -> ([((String,String,Int))],Int)
      foldPat p (ps,cnt)  = ((p2rh p ("UniqueP2rh"++(show cnt)++(show n)) (n+1)):ps,cnt+1)
      (fs,_) = foldr (foldPat) ([],0) fPats
      bs = map (\(_,b,_)->b) fs
      bs' = concat bs
      ids = map (\(i,_,_)->i) fs
      featsN = init $ concat (map (\(x,y)->x++":"++y++" ") $ zip fnms ids)
      ns = foldl (\x (_,_,y)->x+y) 0 fs in
      (id',"local "++id'++" in\n"++bs'++id'++" = "++lbl++"("++featsN++")\n",ns+1)
    p2rh (Parenp p1 op p2) id' n = let
      (id1,b1,n1) = p2rh p1 ("UniqueP2rh1"++(show n)) (n+1)
      (id2,b2,n2) = p2rh p2 ("UniqueP2rh2"++(show n)) (n+1) in
      (id', "local "++id'++" in\n"++b1++b2++id'++" = "++['\'']++op++['\'']++"(1:"++id1++" 2:"++id2++")\n",n1+n2+1) -- n are missing ends
    --p2rh x id' n = error $ "Pattern incorrectly used for in Declaration (only Varp, Rcrd, Parenp allowed)--> "++(show x)
    nub' :: [String] -> [String]
    nub' [] = []
    nub' (x:xs) = if (elem x xs) then nub' xs else x:(nub' xs)

-- used for inDeclaration, will introduce variables in pattern with locals
-- construct a record from the pattern and bind it to the input identifier
pattern2kernel :: Pat -> String -> (String, Int)
pattern2kernel pat id = let 
  (idN,vsN,bN,nN) = p2kh pat id 0
  ends = endWithTab (nN-1) 0 
  lcls = lclsH vsN
  lclsH :: [String] -> String
  lclsH [] = []
  lclsH (x:xs) = "local "++x++" in\n"++(lclsH xs) 
  bNend = ts (bN++ends) 2 in
  (lcls++bNend,length vsN)
  -- get number of Ends by length of vs
  where
    p2kh :: Pat -> String -> Int -> (String,[String],String,Int)
    p2kh (Varp var) id' n = (var,[var],[],0)
    p2kh (Rcrdp lbl feats) id' n = let
      fnms = map fst feats
      fPats = map snd feats 
      foldPat :: Pat -> ([((String,[String],String,Int))],Int) -> ([((String,[String],String,Int))],Int)
      foldPat p (ps,cnt)  = ((p2kh p ("UniqueP2kh"++(show cnt)++(show n)) (n+1)):ps,cnt+1)
      (fs,_) = foldr (foldPat) ([],0) fPats
      bs = map (\(_,_,b,_)->b) fs
      bs' = concat bs
      ids = map (\(i,_,_,_)->i) fs
      featsN = initp $ concat (map (\(x,y)->x++":"++y++" ") $ zip fnms ids)
      initp [] = []
      initp l = init l
      ns = foldl (\x (_,_,_,y)->x+y) 0 fs
      vs' = nub' (concat (map (\(_,x,_,_)->x) fs)) in
      (id',vs',"local "++id'++" in\n"++bs'++id'++" = "++lbl++"("++featsN++")\n",ns+1)
    p2kh (Parenp p1 op p2) id' n = let
      (id1,vars1,b1,n1) = p2kh p1 ("UniqueP2kh1"++(show n)) (n+1)
      (id2,vars2,b2,n2) = p2kh p2 ("UniqueP2kh2"++(show n)) (n+1) in
      (id',nub' (vars1++vars2), "local "++id'++" in\n"++b1++b2++id'++" = "++['\'']++op++['\'']++"(1:"++id1++" 2:"++id2++")\n",n1+n2+1) -- n are missing ends
    p2kh x id' n = error $ "Pattern incorrectly used for in Declaration (only Varp, Rcrd, Parenp allowed)--> "++(show x)
    nub' :: [String] -> [String]
    nub' [] = []
    nub' (x:xs) = if (elem x xs) then nub' xs else x:(nub' xs)

-- *********************************************************************************************************************
-- Expressions

-- used in multiple situations, so it will return a type Exp instead of a string
-- this will allow it to be manipulated in whatever context it appears

type InExp = (String, Exp, String) -- indDclarationPart ++ Stm (optional - empty if non-existant), Exp, Number of Ids declared in declaration part

data Exp = ENum String | EVar String | ERcd Pat | EParen Exp String Exp | EFun [String] InExp | EFunCall String [Exp] |
  ELocal InExp | EIf Exp InExp [(Exp,InExp)] [InExp] | ECase String String InExp [(String,InExp)] [InExp]

instance Show Exp where
  show (ENum s) = show s
  show (EVar s) = show s
  show (ERcd p) = show p
  show (EParen e1 b e2) = show e1 ++ " " ++ show b ++ " " ++ show e2
  show (EFun ps exp) = show ps ++ show exp
  show (EFunCall fname ps) = show fname ++ show ps
  show (ELocal exp) = show exp
  show (EIf ex ine nest el) = show ex ++ show ine ++ show nest ++ show el
  show (ECase id pat ine nest el) = show id ++ show pat ++ show ine ++ show nest ++ show el

rbos :: [Char]
rbos = ['+','-','*','/','<','>']

opPairs :: [(String,String)]
opPairs = [("+","IntPlus"),("-","IntMinus"),("*","Multiply"),("/","Divide"),("<","LessThan"),(">","GreaterThan"),
  ("div","DivideInt"),("mod","Mod"),("==","Eq"),("\\=","NotEqual"),("=<","LessThanEq"),(">=","GreaterThanEq")]

rBinOp :: ParserT String
rBinOp = (:[]) <$> satisfy (\x-> elem x rbos)
  <|> string "div"
  <|> string "mod"
  <|> string "=="
  <|> string "\\="
  <|> string "=<"
  <|> string ">="

pExp :: ParserT Exp
pExp = (ENum <$> pNumK
  <|> EVar <$> pIdentifierK
  <|> try ( ERcd <$> pPattern )
  <|> pEParen
  <|> pEFun 
  <|> pEFunCall
  <|> pELocal 
  <|> pEIf
  <|> pECase) <* scK
  where
    pEParen :: ParserT Exp
    pEParen = do 
      void (charSC '(')
      exp1 <- pExp
      bOp <- rBinOp <* scK
      exp2 <- pExp
      void (char ')')
      return $ EParen exp1 bOp exp2
    pEFun :: ParserT Exp
    pEFun = do 
      void (rwordSC "fun")
      void (charSC '{')
      void (charSC '$')
      parameters <- many (pIdentifierKSC)
      void (charSC '}')
      inExp <- pInExpression
      void (rword "end")
      return $ EFun parameters inExp
    pEFunCall :: ParserT Exp
    pEFunCall = do
      void (charSC '{')
      fName <- pIdentifierKSC
      parameters <- many (pExp)
      void (char '}')
      return $ EFunCall fName parameters
    pELocal :: ParserT Exp
    pELocal = do
      void (rwordSC "local")
      -- must have 'in' slightlt different the inExpression, but we will leave it for semantic checking (=
      inExp <- pInExpression
      void (rword "end")
      return $ ELocal inExp
    pEIf :: ParserT Exp
    pEIf = do
      void (rwordSC "if")
      ex <- pExp
      void (rwordSC "then")
      inExp <- pInExpression
      nest <- many pENestIf
      el <- pEIfElse
      void (rword "end")
      return $ EIf ex inExp nest el
    pENestIf :: ParserT (Exp,InExp)
    pENestIf = try $ do
      void (rwordSC "elseif")
      exN <- pExp
      void (rwordSC "then")
      inExpN <- pInExpression
      return (exN,inExpN)
    pEIfElse :: ParserT [InExp]
    pEIfElse = do 
      el <- optional $ do 
        void (rwordSC "else")
        inExp <- pInExpression
        return inExp
      case el of
        (Just ie) -> return [ie]
        Nothing -> return []
    pECase :: ParserT Exp
    pECase = do 
      void (rwordSC "case")
      id <- pIdentifierKSC
      void (rwordSC "of")
      pattern <- pRecordK <* scK
      void (rwordSC "then")
      inExp <- pInExpression
      nest <- many pENestCase
      el <- pECaseElse
      void (rword "end")
      return $ ECase id pattern inExp nest el
    pENestCase :: ParserT (String,InExp)
    pENestCase = do 
      void (string "[]" <* scK)
      pattern <- pRecordK <* scK
      void (rwordSC "then")
      inExp <- pInExpression
      return (pattern, inExp)
    pECaseElse :: ParserT [InExp]
    pECaseElse = do 
      el <- optional $ do 
        void (rwordSC "else")
        inExp <- pInExpression
        return inExp
      case el of
        (Just ie) -> return [ie]
        Nothing -> return []

remFst s = dropWhile (/= '\n') s

-- unique variable names ... UniqueName[1,2] are protected for the kernel syntax translation purposes
exp2Kernel :: String -> Exp -> String
exp2Kernel = exp2kernel 0
exp2kernel :: Int -> String -> Exp -> String
exp2kernel n var (ENum s) = spcs ((n+1)*2) ++ var ++ " = " ++ s ++ "\n"
exp2kernel n var (EVar s) = spcs ((n+1)*2) ++ var ++ " = " ++ s ++ "\n"
exp2kernel n var (ERcd p) = ts (remFst (pattern2record p var)) ((n+1)*2)
exp2kernel n var (EParen e1 op e2) = 
  let 
    u1 = "UniqueName1" ++ (show n)
    u2 = "UniqueName2" ++ (show n)
    op2ker :: String -> String -> String -> String -> String 
    op2ker x y op var = "{"++(opNameLookup op)++" "++x++" "++y++" "++var++"}\n"
    opNameLookup op1 = head [name | (o,name)<-opPairs , o == op1]
  in
    spcs ((n+1)*2) ++ "local "++u1++" in\n" ++ spcs ((n+2)*2) ++ "local "++u2++" in\n"++
    (exp2kernel (n+3) u1 e1) ++ (exp2kernel (n+3) u2 e2) ++ spcs ((n+3)*2) ++ (op2ker u1 u2 op var)
    ++ spcs ((n+2)*2) ++ "end\n"++spcs ((n+1)*2) ++ "end\n"
exp2kernel n var (EFun params (s,ex,es)) = spcs ((n+1)*2) ++ var ++ 
  " = proc {$ " ++ (concat (map (\s->s++" ") (params))) ++ "ProcOut" ++ (show n) ++ "}\n" ++
  spcs ((n+1)*2) ++ s ++(exp2kernel (n+1) ("ProcOut"++(show n)) ex)++ spcs ((n+2)*2) ++ 
  es ++spcs ((n+1)*2) ++ "end\n"
exp2kernel n var (EFunCall fName params) = 
  let
    foldPat p (ps,cnt)  = (("UniqueP"++(show cnt)++(show n)):ps,cnt+1)
    (ps,_) = foldr (foldPat) ([],0) params
    foldPatE (p,pex) (ls,exs,cnt)  = (("local UniqueP"++(show cnt)++(show n)++" in "):ls,(exp2kernel (n+1) ("UniqueP"++(show cnt)++(show n)) pex):exs,cnt+1)
    (lcls',paramsS,_) = foldr foldPatE ([],[],0) (zip ps params)
    lcls = spcs ((n+1)*2) ++ concat lcls'++"\n"
    ends = endWithTab (length ps) ((n+1)*2)
  in
    (lcls)++(concat (paramsS))++spcs ((n+2)*2) ++ 
    "{"++fName++" "++(concat (map (\p->p++" ") ps))++" "++var++"}\n"++ends
exp2kernel n var (ELocal (s,ex,es)) = spcs ((n+1)*2) ++ s++(exp2kernel (n+1) var ex)++spcs ((n+1)*2) ++ es 
exp2kernel n var (EIf ex (s,ex1,es) nest el) =
  let 
    lcl = spcs ((n+1)*2) ++ "local UniqueIf in \n"
    exDec = (exp2kernel (n+1) "UniqueIf" ex)
    if1 = spcs ((n+2)*2) ++ "if UniqueIf then\n"++spcs ((n+3)*2) ++ s
    ifE = ((exp2kernel (n+2) var ex1) ++ es)
    elT = spcs ((n+2)*2) ++ "else\n"
    (nestS,nestC) = unfoldNestIf 3 nest var
    oElse = checkElse (nestC*2) el var
    elseT = if nestC == 0 then "" else spcs ((n+2*nestC)*2) ++ "else\n"
    endsT = endWithTab (nestC*2+2) ((n+1)*2)
    unfoldNestIf :: Int -> [(Exp,InExp)] -> String -> (String,Int)
    unfoldNestIf c [] var = ([],0)
    unfoldNestIf c ((ex,(s,ex1,es)):xs) var = 
        let 
          lcl = spcs ((n+c)*2) ++ "local UniqueIf in \n"
          exDec = (exp2kernel (n+c) "UniqueIf" ex)
          if1 = spcs ((n+c+1)*2) ++ "if UniqueIf then\n"++spcs ((n+c+2)*2) ++ s
          ifE = ((exp2kernel (n+c+2) var ex1) ++ spcs ((n+c+2)*2) ++ es)
          (nestS,nestC) = unfoldNestIf (c+2) xs var
          elT = spcs ((n+c)*2) ++ "else\n"
        in
          if nestS == []  
            then (lcl++exDec++if1++ifE,1)
            else (lcl++exDec++if1++ifE++elT++nestS,nestC+1)
    checkElse :: Int -> [InExp] -> String -> String
    checkElse c [] _ = spcs ((n+c)*2) ++ "skip Basic\n"
    checkElse c ((s,ex1,es):xs) var =
      spcs ((n+1)*2) ++ s++(exp2kernel (n+c) var ex1)++spcs ((n+c)*2) ++ es
  in
    lcl++exDec++if1++ifE++elT++nestS++elseT++oElse++endsT
exp2kernel n var (ECase id patt (s,ex,es) nest el) =
  let
    cs = spcs ((n+1)*2) ++ "case "++id++" of \n"++spcs ((n+2)*2) ++ patt++" then\n"
    cs1 = spcs ((n+3)*2) ++ s
    csE = ((exp2kernel (n+3) var ex) ++ es)
    elT = spcs ((n+2)*2) ++ ("else\n")
    (nestS,nestC) = unfoldNestC 2 nest var
    oElse = checkElse (nestC*3+2) el var
    elseT = if nestC == 0 then "" else spcs ((n+nestC*2)*2) ++ "else\n"
    endsT = endWithTab (nestC+1) ((n+1)*2)
    unfoldNestC :: Int -> [(String,InExp)] -> String -> (String,Int)
    unfoldNestC c [] var = ([],0)
    unfoldNestC c ((patt,(s,ex1,es)):xs) var = 
      let
        cs = spcs ((n+c)*2) ++ "case "++id++" of \n"++spcs ((n+c+1)*2) ++ patt++" then\n"
        cs1 = spcs ((n+c+2)*2) ++ s
        csE = ((exp2kernel (n+c+2) var ex1) ++ spcs ((n+c+3)*2) ++ es)
        elT = spcs ((n+c+1)*2) ++ ("else\n")
        (nestS,nestC) = unfoldNestC (c+3) xs var
      in
        if nestS == []
          then (cs++cs1++csE,1)
          else (cs++cs1++csE++elT++nestS,nestC+1)
    checkElse :: Int -> [InExp] -> String -> String
    checkElse c [] _ = spcs ((n+c)*2) ++ "skip Basic\n"
    checkElse c ((s,ex1,es):xs) var =
      spcs ((n+c)*2) ++ s++(exp2kernel (n+c) var ex1)++spcs ((n+c)*2) ++ es
  in
    cs++cs1++csE++elT++nestS++elseT++oElse++endsT

pInExpression :: ParserT InExp
pInExpression = try $ do
  decPart <- optional pDeclarationPart
  s <- many pStatementK
  e <- pExp
  case decPart of 
    (Just (dec,n)) -> do
      let ends = endWithTab n 0
      return (dec++(concat s),e,ends)
    Nothing -> return ((concat s),e,"")

-- *********************************************************************************************************************
-- Value

pValueK :: ParserT String
pValueK = pNumK  
  <|> pRecordK
  <|> pProcedureK

pValueKSC :: ParserT String
pValueKSC = pValueK <* scK

-- https://mmhaskell.com/parsing-4 for number example
pNumK :: ParserT String
pNumK = pNegativeK <|> pFloatK <|> pIntegerK
  where
    pFloatK :: ParserT String
    pFloatK = try $ do
      whole <- many digitChar
      void (char '.')
      fractional <- many digitChar
      let num = whole ++ ('.':fractional)
      return num
    pIntegerK :: ParserT String
    pIntegerK = try $ do
      int <- some digitChar
      let num = int
      return num
    pNegativeK :: ParserT String
    pNegativeK = try $ do
      void (char '-')
      num <- pFloatK <|> pIntegerK
      return ('-':num)

pRecordK :: ParserT String
pRecordK = try $ do
  label <- pLiteralK
  openParen <- (optional . try) (char '(')
  features <- (case openParen of
        (Just x) -> do 
          ps <- many pPairsK
          char ')'
          scK
          return ps
        Nothing -> do
          scK
          return [])
  return (label ++ "(" ++ (concat features)++ ")")
  where
    pPairsK :: ParserT String
    pPairsK = do
      feat <- pFeatureK
      void (char ':')
      identifier <- pIdentifierKSC
      return (feat ++ ":" ++ identifier ++ " ") 

pProcedureK :: ParserT String
pProcedureK = try $ do
  void (rwordSC "proc")
  void (charSC '{')
  void (charSC '$')
  parameters <- many ((++) <$> pIdentifierK <*> spaceK) -- space after ...
  void (charSC '}')
  modify (+2)
  body <- pStatementK -- statement parser
  modify (subtract 2)
  void (string "end")
  return ("proc " ++ "{$ "++(concat parameters)++"}\n"++body++"end\n")

-- NO BOOL becuase it is a differnt type (Val not string)
pLiteralK :: ParserT String
pLiteralK = pAtomK

pFeatureK :: ParserT String
pFeatureK = 
  try pAtomK <|>
  do 
    n1 <- digitChar
    num <- many digitChar
    return (n1:num)

pBoolK :: ParserT String
pBoolK = 
  ("True") <$ string "True" <|>
  ("False") <$ string "False"

-- Helper functions/parser
-- reserved word parsers
rword :: String -> ParserT String
rword w = (try) (string w <* notFollowedBy alphaNumChar)

rwordSC :: String -> ParserT String
rwordSC w = rword w <* scK

-- reserved words
rws :: [String]
rws = ["skip","local","in","end","case","of","if","else","then","proc","Browse","elseif","fun"]

-- parsing an identifier 
-- starts with upper case letter, cannot be a reserved word
-- no underscore, no quote names
pIdentifierK :: ParserT String
pIdentifierK = try (p >>= check)
  where
    p = (:) <$> upperChar <*> many alphaNumChar
    check x = if x `elem` rws
          then fail $ "keyword " ++ show x ++ " cannot be an identifier"
          else return x

pIdentifierKSC :: ParserT String
pIdentifierKSC = pIdentifierK <* scK

-- parsing an atom
-- starts with lower case letter, cannot be reserved word
-- OR
-- starts with single quote, ends with single quote
pAtomK :: ParserT String 
pAtomK = try ( (p >>= check) <|> pSingleQuotes)
  where
    p = (:) <$> lowerChar <*> many alphaNumChar
    check x = if x `elem` rws
          then fail $ "keyword " ++ show x ++ " cannot be an identifier"
          else return x
    pSingleQuotes = do 
      x <- singleQuotes
      return ("\'"++x++"\'")
    singleQuotes = between (char '\'') (char '\'') (many (satisfy (not . (== '\''))))

-- End Value
-- *********************************************************************************************************************

-- *********************************************************************************************************************
-- Statements

pStatementsK :: ParserT String
pStatementsK = do 
  put(0)
  between scK eof pStatementK

pStatementK :: ParserT String
pStatementK = do 
  s1 <-
    pSkipK   <|>
    pLocalK   <|>
    pBindK    <|>
    pBindValK <|>
    pBindPat <|>
    pBindExp <|>
    pIfK      <|>
    pCaseK    <|>
    pProcAppK <|>
    pProcDef <|>
    pFun
  s2 <- (optional . try) $ pStatementK
  return $
    case s2 of 
      Nothing -> s1
      Just stm -> (s1 ++ stm)

pSkipK :: ParserT String
pSkipK = try $ do 
  string "skip" <* scK
  pSkipB
    <|> pSkipS
    <|> pSkipF
    <|> pSkipC
    <|> pSkipBr
    <|> pSkipSt
  where
    pSkipB = try $ do {string "Basic" <* scK; tsm "skip Basic\n"}
    pSkipS = try $ do {string "Store" <* scK; tsm "skip Store\n"}
    pSkipF = try $ do {string "Full" <* scK; tsm "skip Full\n"}
    pSkipC = try $ do {string "Check" <* scK; tsm "skip Check\n"}
    pSkipSt = try $ do {string "Stack" <* scK; tsm "skip Stack\n"}
    pSkipBr = try $ do
      string "Browse" <* scK
      id <- pIdentifierKSC
      tsm $ "skip Browse "++id++"\n"

pLocalK :: ParserT String
pLocalK = try $ do
  void (rwordSC "local")
  decl <- pInStatement
  void (rwordSC "end")
  return decl

pBindK :: ParserT String
pBindK = try $ do
  identifier1 <- pIdentifierKSC
  void (charSC '=')
  identifier2 <- pIdentifierKSC
  tsm $ identifier1++" = "++identifier2++"\n"

pBindValK :: ParserT String
pBindValK = try $ do
  identifier1 <- pIdentifierKSC
  void (charSC '=')
  val <- pValueKSC
  tsm $ identifier1++" = "++val++"\n"

pBindPat :: ParserT String
pBindPat = try $ do
  identifier1 <- pIdentifierKSC
  void (charSC '=')
  pat <- pPattern
  let patternBuild = pattern2record pat "UniqueNameBP"
      bind = identifier1 ++ " = UniqueNameBP\nend\n"
  tsm $ patternBuild++bind

pBindExp :: ParserT String 
pBindExp = try $ do
  identifier1 <- pIdentifierKSC
  void (charSC '=')
  exp1 <- pExp
  return $ exp2Kernel identifier1 exp1

-- changed to accept expression, inStatement, nesting
-- -> if <Exp> then <InStatement> {elseif <Exp> then <InStatement} [else <InStatement>]
pIfK :: ParserT String
pIfK = try $ do
  void (rwordSC "if")
  pTab <- get
  exp1 <- pExp
  void (rwordSC "then")
  modify (+4)
  inStm <- pInStatement
  optNest <- optional (pIfNest 0) -- optional nested if statements
  optElse <- optional (rwordSC "else") -- optional else statement
  oElse <- (case optElse of
    (Just s) -> do
      s2 <- pInStatement
      sps5 <- scK
      return s2
    Nothing  -> do return $ ts "skip Basic\n" (4))
  void (rwordSC "end")
  modify (subtract 4)
  -- put it all back together before returning
  let 
    (oNest,nestCnt) = (case optNest of
      (Just (s,n)) -> (s,n)
      Nothing  -> ([],0))
    expT = ts (exp2Kernel "UniqueIF" exp1) (pTab+2) 
    lcl = ts ("local "++"UniqueIF in\n") pTab ++expT
    ifT = ts "if UniqueIF then\n" (pTab+2)
    elT = ts ("else\n") (pTab+2)
    elseT = case nestCnt of
      0 -> ""
      _ -> ts "else\n" (nestCnt*4+pTab+2)
    elOT = ts oElse (max(nestCnt*2-4) 0)
    endsT = endWithTab (nestCnt*2+2) (pTab) 
  return $ lcl++ifT++inStm++elT++oNest++elseT++elOT++endsT

-- If pTab <- get is at end of the function, it will cause an infinite loop for some reason (=

pIfNest :: Int -> ParserT (String,Int)
pIfNest n = try $ do
  void (rwordSC "elseif")
  pTab <- get
  exp1 <- pExp
  void (rwordSC "then")
  modify (+4)
  body <- pInStatement
  nest <- optional (pIfNest (n))
  let 
    expT = ts (exp2Kernel "UniqueNIF" exp1) (pTab+2)
    lcl = (ts ("local "++"UniqueNIF in \n") pTab)++expT
    ifT = ts ("if UniqueNIF then\n") (pTab+2)
    elT = ts ("else\n") (pTab+2)
  modify (subtract 4)
  case nest of
    (Just (x,n')) -> return $ (lcl++ifT++body++elT++x,n'+1)
    Nothing  -> return $ (lcl++ifT++body,n+1) -- left before the else

-- case <X> of <rcrd> then <S>
-- {[] <rcrd> then <S>}
-- [else <S>] end

pCaseK :: ParserT String
pCaseK = try $ do
  void (rwordSC "case")
  pTab <- get
  identifier <- pIdentifierKSC
  void (rwordSC "of")
  pattern <- pRecordK <* scK
  void (rwordSC "then")
  modify (+ 2)
  s1 <- pInStatement
  optNest <- optional (pCaseNest identifier) -- optional nested if statements
  optElse <- optional (rwordSC "else") -- optional else statement
  oElse <- (case optElse of
    (Just s) -> do
      s2 <- pInStatement
      sps5 <- scK
      return s2
    Nothing  -> do return $ ts "skip Basic\n" (2))
  void (rwordSC "end")
  modify ((-)2)
  -- put it all back together before returning
  cs <- tsm ("case "++identifier++"\nof "++pattern++" then\n")
  let 
    (oNest,nestCnt) = case optNest of
      (Just (s,n)) -> (s,n)
      Nothing  -> ([],0)
    elT = ts ("else\n") (pTab)
    elseT = case nestCnt of
      0 -> ""
      _ -> ts "else\n" (nestCnt*2+pTab)
    elOT = ts oElse (nestCnt*2)
    endsT = endWithTab (nestCnt+1) (pTab) 
  return $ cs++s1++elT++oNest++elseT++elOT++endsT

pCaseNest :: String -> ParserT (String,Int)
pCaseNest id = try $ do
  void (string "[]" <* scK)
  pTab <- get
  pattern <- pRecordK
  void (rwordSC "then")
  modify (+ 2)
  stm <- pInStatement
  nest <- optional (pCaseNest id)
  modify (subtract 2)
  let 
    cs = ts ("case "++id++"\nof "++pattern++" then\n") (pTab)
    elT = ts ("else\n") (pTab)
  case nest of
    (Just (x,n')) -> return $ (cs++stm++elT++x,n'+1)
    Nothing  -> return $ (cs++stm,1) -- left before the else

pProcAppK :: ParserT String
pProcAppK = try $ do
  void (charSC '{')
  procIdentifier <- pIdentifierKSC
  arguments <- many ((++) <$> pIdentifierK <*> scK) -- include white space take
  void (charSC '}')
  tsm $ "{"++procIdentifier++" "++(concat arguments)++"}\n"

-- define a procedure
-- {X Y C} skip end --> X = {$ Y C} skip end
pProcDef :: ParserT String
pProcDef = try $ do
  pTab <- get
  void (rwordSC "proc")
  void (charSC '{')
  id <- pIdentifierKSC
  parameters <- many ((++) <$> pIdentifierK <*> scK) -- space after ...
  trace "}" $ void (charSC '}')
  body <- pInStatement -- statement parser
  let x = trace body body
  seq x $ void (rwordSC "end")
  return $ (trace (id++" = proc {$ "++(concat parameters)++"} \n"++body++"end\n") (id++" = proc {$ "++(concat parameters)++"} \n"++body++"end\n"))

pFun :: ParserT String
pFun = try $ do
  void (rwordSC "fun")
  void (charSC '{')
  id <- pIdentifierKSC
  parameters <- many ((++) <$> pIdentifierK <*> spaceK) -- space after ...
  void (charSC '}')
  (body,e,ends) <- pInExpression
  void (rwordSC "end")
  pTab <- get
  let 
    expS = exp2Kernel "OutUnique" e
    bodyNew = body ++ (ts expS pTab) ++ (ts ends pTab)
  --Convert InExpression To a Regular Expression (pass in id)
  fs <- tsm (id++" = proc " ++ "{$ "++(concat parameters)++" OutUnique}")
  return $ fs++bodyNew++ts "end\n" pTab

-- *********************************************************************************************************************
-- main functions

mainK :: IO ()
mainK = do 
  input <- getContents
  let (s,n) = runState (runParserT pStatementsK "" input) 0
  case s of
    (Left bundle) -> putStr (errorBundlePretty bundle)
    (Right xs) -> do 
      writeFile "Femp.txt" xs


-- ghci run
-- ghci> main' "infile.txt" "outfile.txt"
--   Haskell statement structure written to output file
--   calls to Skip displays are written to terminal
mainK' :: String -> String -> String -> IO ()
mainK' inF kernO outF = do 
  input <- readFile inF
  let (s,n) = runState (runParserT pStatementsK "" input) 0
  case s of
    (Left bundle) -> putStr (errorBundlePretty bundle)
    (Right xs) -> do
      writeFile kernO xs
      main' kernO outF 















